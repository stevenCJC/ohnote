(function(window) {
  var Styles = {
    InLine: { display: "inline-block" },
    ButtonGroup: { marginRight: "5px" },
    Content: {
      height: "194px",
      border: "1px solid #ccc",
      overflow: "scroll"
    },
    HTMLButton: {
      display: "inline-block",
      float: "right"
    },
    HTML: {
      height: "194px",
      border: "1px solid #ccc",
      overflow: "scroll",
      display: "none"
    }
  }

  var TIPS = {
    "bold-btn": "Bold selection",
    "italic-btn": "Italicize selection",
    "underline-btn": "Underline selection",
    "strikeThrough-btn": "Strikethrough selection",
    "font-size-btn-group": "Selection fontsize",
    "font-color-btn-group": "Selection fontcolor",
    "superscript-btn": "Superscript selection",
    "subscript-btn": "Subscript selection",
    "H1-btn": "Heading type #1",
    "P-btn": "Paragraph text",
    "BLOCKQUOTE-btn": "Blockquote text",
    "bulleted-btn": "Make a bulleted list",
    "numbered-btn": "Make a numbered list",
    "horzline-btn": "Add a horizontal line",
    "justifyLeft-btn": "Left justify selection",
    "justifyCenter-btn": "Center justify selection",
    "justifyRight-btn": "Right justify selection",
    "indent-btn": "Indent select text selection",
    "outdent-btn": "Outdent select text selection",
    "link-btn": "Insert a link",
    "img-btn": "Insert an image",
    "vid-btn": "Insert a video",
    "iframe-btn": "Insert an iframe",
    "undo-btn": "Undo",
    "redo-btn": "Redo",
    "all-btn": "Select all",
    "remove-format-btn": "Remove selection formatting",
  }

  var Editor = React.createClass({displayName: "Editor",
    getInitialState: function() {
      return {
        selection: window.getSelection() || document.getSelection() || document.selection,
        range: null,
        spanCounter: 0
      }
    },
    onContent: function() {
      this.setState({ range: this.state.selection.getRangeAt(0) })
    },
    changeSelectionCSS: function(property, details) {
      if (!this.state.range) return;

      var id = "text-" + this.state.spanCounter.toString(),
          newNode = document.createElement("span");
      newNode.id = id;
      this.state.range.surroundContents(newNode);
      this.state.spanCounter += 1;

      var elem = document.getElementById(id),
          prop = property === "font-size" ? "fontSize" : "color",
          det = property === "font-size" ? details + "px" : details;
      elem.style[prop] = det;

      this.state.range = null;
    },
    showHTML: function(html) {
      document.getElementById("editor-content").style.display = "none";
      var htmlElem = document.getElementById("html-content");
      htmlElem.innerText = html;
      htmlElem.style.display = "";
    },
    hideHTML: function() {
      document.getElementById("editor-content").style.display = "";
      document.getElementById("html-content").style.display = "none";
    },
    componentDidMount: function() {
      if (this.props.tooltips) {
        for (var btn in TIPS) {
          var tip = TIPS[btn];
          $("#" + btn).tooltip({
            trigger: "hover",
            title: tip,
            placement: "bottom"
          });
        }
      }
    },
    render: function() {
      var codeButton;
      if (this.props.showHTMLButton) {
        codeButton = React.createElement(HTMLButton, {show: this.showHTML, hide: this.hideHTML})
      }

      return (  
        React.createElement("div", {id: "ARTERY"}, 
          React.createElement("div", {className: "panel panel-info"}, 
            React.createElement("div", {className: "panel-heading"}, 
              React.createElement(SaveButton, {on: this.props.onSave}), 
              React.createElement("div", {id: "edit-btns", style: Styles.InLine}, 
                React.createElement("div", {id: "font-btns", className: "btn-group", style: Styles.ButtonGroup}, 
                  React.createElement(FontButton, {action: "bold"}), 
                  React.createElement(FontButton, {action: "italic"}), 
                  React.createElement(UnderlineButton, null), 
                  React.createElement(StrikethroughButton, null), 
                  React.createElement(FontSizeButtonGroup, {
                    sizes: [8, 10, 12, 14, 16, 18, 20, 22, 24, 26, 28, 30], 
                    act: this.changeSelectionCSS}), 
                  React.createElement(FontColorButtonGroup, {
                    colors: ["black", "red", "green", "blue", "yellow", "purple", "grey"], 
                    act: this.changeSelectionCSS}), 
                  React.createElement(ScriptButton, {action: "superscript"}), 
                  React.createElement(ScriptButton, {action: "subscript"})
                ), 
                React.createElement("div", {id: "heading-btns", className: "btn-group", style: Styles.ButtonGroup}, 
                  React.createElement(HeadingButton, {heading: "H1", icon: "header"}), 
                  React.createElement(HeadingButton, {heading: "P", text: "P"}), 
                  React.createElement(HeadingButton, {heading: "BLOCKQUOTE", icon: "comment"})
                ), 
                React.createElement("div", {id: "organization-btns", className: "btn-group", style: Styles.ButtonGroup}, 
                  React.createElement(ListButton, {name: "bulleted", icon: "list", action: "insertUnorderedList"}), 
                  React.createElement(ListButton, {name: "numbered", icon: "list-alt", action: "insertOrderedList"}), 
                  React.createElement(HorizontalLine, null), 
                  React.createElement(JustifyButton, {action: "justifyLeft", icon: "align-left"}), 
                  React.createElement(JustifyButton, {action: "justifyCenter", icon: "align-center"}), 
                  React.createElement(JustifyButton, {action: "justifyRight", icon: "align-right"}), 
                  React.createElement(JustifyButton, {action: "indent", icon: "indent-left"}), 
                  React.createElement(JustifyButton, {action: "outdent", icon: "indent-right"})
                ), 
                React.createElement("div", {id: "data-btns", className: "btn-group", style: Styles.ButtonGroup}, 
                  React.createElement(DataButton, {name: "link", icon: "link"}), 
                  React.createElement(DataButton, {name: "img", icon: "picture"}), 
                  React.createElement(DataButton, {name: "vid", icon: "facetime-video"}), 
                  React.createElement(DataButton, {name: "iframe", icon: "globe"})
                ), 
                React.createElement("div", {id: "undo-btns", className: "btn-group", style: Styles.ButtonGroup}, 
                  React.createElement(UndoButton, {name: "undo", icon: "arrow-left", action: "undo"}), 
                  React.createElement(UndoButton, {name: "redo", icon: "arrow-right", action: "redo"}), 
                  React.createElement(UndoButton, {name: "all", icon: "font", action: "selectAll"}), 
                  React.createElement(UndoButton, {name: "remove-format", icon: "trash", action: "removeFormat"})
                ), 
                codeButton
              )
            ), 
            React.createElement("div", {
              id: "editor-content", 
              className: "form-control", 
              contentEditable: "true", 
              style: Styles.Content, 
              onClick: this.onContent}
            ), 
            React.createElement("div", {
              id: "html-content", 
              type: "text", 
              rows: "9", 
              className: "form-control", 
              style: Styles.HTML, 
              readOnly: true}
              )
          ), 
          React.createElement(LinkModal, null), 
          React.createElement(ImageModal, null), 
          React.createElement(VideoModal, null), 
          React.createElement(IFrameModal, null)
        )
      );
    }
  });

  var SaveButton = React.createClass({displayName: "SaveButton",
    render: function() {
      return (
        React.createElement("button", {
          id: "save-btn", 
          type: "button", 
          className: "btn btn-default", 
          style: Styles.ButtonGroup, 
          onClick: this.props.on}, "Save"
        )
      ); 
    }
  });

  var HTMLButton = React.createClass({displayName: "HTMLButton",
    getInitialState: function() {
      return {on: false, text: 'HTML'};
    },
    act: function() {
      if (this.state.on) {
        this.setState({on: false, text: 'HTML'});
        this.props.hide();
      } else {
        this.setState({on: true, text: 'Text'});
        var html = document.getElementById("editor-content").innerHTML;
        this.props.show(html);
      }
    },
    render: function() {
      return (
          React.createElement("button", {
            id: "code-btn", 
            type: "button", 
            className: "btn btn-default", 
            style: Styles.HTMLButton, 
            onClick: this.act}, 
            this.state.text
          )
      );
    }
  });

  var FontButton = React.createClass({displayName: "FontButton",
    act: function() {
      document.execCommand(this.props.action, false, null);
    },
    render: function() {
      var id = this.props.action + "-btn",
          spanClass = "glyphicon glyphicon-" + this.props.action;
      return (
        React.createElement("button", {id: id, type: "button", className: "btn btn-primary", onClick: this.act}, 
          React.createElement("span", {className: spanClass})
        )
      );
    }
  });

  var UnderlineButton = React.createClass({displayName: "UnderlineButton",
    act: function() {
      document.execCommand("underline", false, null);
    },
    render: function() {
      return (
        React.createElement("button", {id: "underline-btn", type: "button", className: "btn btn-primary", onClick: this.act}, 
          React.createElement("u", null, "U")
        )
      );
    }
  });

  var StrikethroughButton = React.createClass({displayName: "StrikethroughButton",
    act: function() {
      document.execCommand("strikeThrough", false, null);
    },
    render: function() {
      return (
        React.createElement("button", {id: "strikeThrough-btn", type: "button", className: "btn btn-primary", onClick: this.act}, 
          React.createElement("s", null, "S")
        )
      );
    }
  });

  var HeadingButton = React.createClass({displayName: "HeadingButton",
    act: function() {
      document.execCommand("formatBlock", false, this.props.heading);
    },
    render: function() {
      var id = this.props.heading + "-btn", inner;
      if (this.props.text) {
        inner = React.createElement("b", null, this.props.text)
      } else {
        var className = "glyphicon glyphicon-" + this.props.icon;
        inner = React.createElement("span", {className: className});
      }
      return (
        React.createElement("button", {id: id, type: "button", className: "btn btn-primary", onClick: this.act}, 
          inner
        )
      );
    },
  });

  var FontSizeButton = React.createClass({displayName: "FontSizeButton",
    act: function() {
      this.props.act("font-size", this.props.size);
    },
    render: function() {
      var sizeStr = this.props.size.toString();
      return (
        React.createElement("li", {className: "font-size-btn", onClick: this.act}, 
          React.createElement("a", null, sizeStr)
        )
      );
    }
  });

  var FontSizeButtonGroup = React.createClass({displayName: "FontSizeButtonGroup",
    render: function() {
      var f = this.props.act;
      return (
        React.createElement("div", {className: "btn-group"}, 
          React.createElement("button", {id: "font-size-btn-group", type: "button", className: "btn btn-primary dropdown-toggle", "data-toggle": "dropdown"}, 
            React.createElement("span", {className: "glyphicon glyphicon-text-height"}), React.createElement("span", {className: "caret"})
          ), 
          React.createElement("ul", {id: "font-size-menu", className: "dropdown-menu", role: "menu"}, 
            this.props.sizes.map(function(size) {
              return React.createElement(FontSizeButton, {key: size, size: size, act: f});
            })
          )
        )
      );
    }
  });

  var FontColorButton = React.createClass({displayName: "FontColorButton",
    act: function() {
      this.props.act("color", this.props.color);
    },
    render: function() {
      var color = this.props.color,
          title = color[0].toUpperCase() + color.substring(1);
      return (
        React.createElement("li", {className: "font-color-btn", onClick: this.act}, 
          React.createElement("a", null, title)
        )
      );
    }
  });

  var FontColorButtonGroup = React.createClass({displayName: "FontColorButtonGroup",
    render: function() {
      var f = this.props.act;
      return (
        React.createElement("div", {className: "btn-group"}, 
          React.createElement("button", {id: "font-color-btn-group", type: "button", className: "btn btn-primary dropdown-toggle", "data-toggle": "dropdown"}, 
            React.createElement("span", {className: "glyphicon glyphicon-tint"}), React.createElement("span", {className: "caret"})
          ), 
          React.createElement("ul", {id: "font-color-menu", className: "dropdown-menu", role: "menu"}, 
            this.props.colors.map(function(color) {
              return React.createElement(FontColorButton, {key: color, color: color, act: f});
            })
          )
        )
      );
    }
  });

  var ScriptButton = React.createClass({displayName: "ScriptButton",
    act: function() {
      document.execCommand(this.props.action, false, null);
    },
    render: function() {
      var id = this.props.action + "-btn",
          sub = this.props.action.substring(2, 3) === "b",
          spanClass = "glyphicon glyphicon-chevron-" + (sub ? "down" : "up");
      return (
        React.createElement("button", {id: id, type: "button", className: "btn btn-primary", onClick: this.act}, 
          React.createElement("span", {className: spanClass})
        )
      );
    }
  });

  var ListButton = React.createClass({displayName: "ListButton",
    act: function() {
      document.execCommand(this.props.action, false, null);
    },
    render: function() {
      var id = this.props.name + "-btn",
          spanClass = "glyphicon glyphicon-" + this.props.icon;
      return (
        React.createElement("button", {id: id, type: "button", className: "btn btn-primary", onClick: this.act}, 
          React.createElement("span", {className: spanClass})
        )
      );
    }
  });

  var HorizontalLine = React.createClass({displayName: "HorizontalLine",
    act: function() {
      document.execCommand("insertHorizontalRule", false, null);
    },
    render: function() {
      return (
        React.createElement("button", {id: "horzline-btn", type: "button", className: "btn btn-primary", onClick: this.act}, 
          React.createElement("span", {className: "glyphicon glyphicon-minus"})
        )
      );
    }
  });

  var JustifyButton = React.createClass({displayName: "JustifyButton",
    act: function() {
      document.execCommand(this.props.action, false, null);
    },
    render: function() {
      var id = this.props.action + "-btn",
          spanClass = "glyphicon glyphicon-" + this.props.icon;
      return (
        React.createElement("button", {id: id, type: "button", className: "btn btn-primary", onClick: this.act}, 
          React.createElement("span", {className: spanClass})
        )
      );
    }
  });

  var LinkModal = React.createClass({displayName: "LinkModal",
    insertLink: function() {
      var url = document.getElementById("insert-link-field").value;
      document.execCommand("createLink", false, url);
    },
    removeLink: function() {
      document.execCommand("unlink", false, null);
    },
    render: function() {
      return (
        React.createElement("div", {className: "modal fade", id: "insert-link-modal", tabIndex: "-1", role: "dialog", "aria-labelledby": "", "aria-hidden": "true"}, 
          React.createElement("div", {className: "modal-dialog"}, 
            React.createElement("div", {className: "modal-content"}, 
              React.createElement("div", {className: "modal-header"}, 
                React.createElement("button", {type: "button", className: "close", "data-dismiss": "modal"}, React.createElement("span", {"aria-hidden": "true"}, "×"), React.createElement("span", {className: "sr-only"}, "Close")), 
                React.createElement("h4", {className: "modal-title", id: "insert-link-modal-title"}, "Insert Link")
              ), 
              React.createElement("div", {className: "modal-body"}, 
                React.createElement("div", {className: "form-group"}, 
                  React.createElement("input", {id: "insert-link-field", type: "text", className: "form-control", placeholder: "Link"})
                ), 
                React.createElement("div", {className: "form-group"}, 
                  React.createElement("button", {id: "insert-link-btn", type: "button", className: "btn btn-primary", onClick: this.insertLink}, 
                    React.createElement("span", {className: "glyphicon glyphicon-ok"}, " ", 
                      React.createElement("label", null, "Insert Link")
                    )
                  )
                ), 
                React.createElement("div", {className: "form-group"}, 
                  React.createElement("button", {id: "remove-link-btn", type: "button", className: "btn btn-primary", onClick: this.removeLink}, 
                    React.createElement("span", {className: "glyphicon glyphicon-remove-circle"}, " ", 
                      React.createElement("label", null, "Remove Link")
                    )
                  )
                )
              ), 
              React.createElement("div", {className: "modal-footer"}, 
                React.createElement("button", {type: "button", className: "btn btn-default", "data-dismiss": "modal"}, "Close")
              )
            )
          )
        )
      );
    }
  });

  var ImageModal = React.createClass({displayName: "ImageModal",
    act: function() {
      var url = document.getElementById("insert-img-field").value;
      document.execCommand("insertImage", false, url);
    },
    render: function() {
      return (
        React.createElement("div", {className: "modal fade", id: "insert-img-modal", tabIndex: "-1", role: "dialog", "aria-labelledby": "", "aria-hidden": "true"}, 
          React.createElement("div", {className: "modal-dialog"}, 
            React.createElement("div", {className: "modal-content"}, 
              React.createElement("div", {className: "modal-header"}, 
                React.createElement("button", {type: "button", className: "close", "data-dismiss": "modal"}, React.createElement("span", {"aria-hidden": "true"}, "×"), React.createElement("span", {className: "sr-only"}, "Close")), 
                React.createElement("h4", {className: "modal-title", id: "insert-img-modal-title"}, "Insert Image")
              ), 
              React.createElement("div", {className: "modal-body"}, 
                React.createElement("div", {className: "form-group"}, 
                  React.createElement("input", {id: "insert-img-field", type: "text", className: "form-control", placeholder: "Image URL"})
                ), 
                React.createElement("div", {className: "form-group"}, 
                  React.createElement("button", {id: "insert-img-btn", type: "button", className: "btn btn-primary", onClick: this.act}, 
                    React.createElement("span", {className: "glyphicon glyphicon-ok"}, " ", 
                      React.createElement("label", null, "Insert Image")
                    )
                  )
                )
              ), 
              React.createElement("div", {className: "modal-footer"}, 
                React.createElement("button", {type: "button", className: "btn btn-default", "data-dismiss": "modal"}, "Close")
              )
            )
          )
        )
      );
    }
  });

  var VideoModal = React.createClass({displayName: "VideoModal",
    act: function() {
      var url = document.getElementById("insert-vid-field").value,
          width = parseInt(document.getElementById("vid-width-field").value) || 500,
          height = parseInt(document.getElementById("vid-height-field").value) || 300,
          html = ["<br>",
            "<video src=\"" + url + "\" width=\"" + width + "\" height=\"" + height + "\"" + " controls></video>",
            "<br>"
          ].join("\n");
      document.execCommand("insertHTML", false, html);
    },
    render: function() {
      return (
        React.createElement("div", {className: "modal fade", id: "insert-vid-modal", tabIndex: "-1", role: "dialog", "aria-labelledby": "", "aria-hidden": "true"}, 
          React.createElement("div", {className: "modal-dialog"}, 
            React.createElement("div", {className: "modal-content"}, 
              React.createElement("div", {className: "modal-header"}, 
                React.createElement("button", {type: "button", className: "close", "data-dismiss": "modal"}, React.createElement("span", {"aria-hidden": "true"}, "×"), React.createElement("span", {className: "sr-only"}, "Close")), 
                React.createElement("h4", {className: "modal-title", id: "insert-vid-modal-title"}, "Insert Video")
              ), 
              React.createElement("div", {className: "modal-body"}, 
                React.createElement("p", null, 
                  "Note: YouTube and Vimeo (and possibly others) tend to provide iframe embed code. If" + ' ' +
                  "you have that, click the globe button next to the video button and paste it in. Thanks!"
                ), 
                React.createElement("div", {className: "form-group"}, 
                  React.createElement("input", {id: "insert-vid-field", type: "text", className: "form-control", placeholder: "Video URL"})
                ), 
                React.createElement("div", {className: "form-group"}, 
                  React.createElement("input", {id: "vid-width-field", type: "text", className: "form-control", placeholder: "Width (Default 500 pixels)"})
                ), 
                React.createElement("div", {className: "form-group"}, 
                  React.createElement("input", {id: "vid-height-field", type: "text", className: "form-control", placeholder: "Height (Default 300 pixels)"})
                ), 
                React.createElement("div", {className: "form-group"}, 
                  React.createElement("button", {id: "insert-vid-btn", type: "button", className: "btn btn-primary", onClick: this.act}, 
                    React.createElement("span", {className: "glyphicon glyphicon-ok"}, " ", 
                      React.createElement("label", null, "Insert Video")
                    )
                  )
                )
              ), 
              React.createElement("div", {className: "modal-footer"}, 
                React.createElement("button", {type: "button", className: "btn btn-default", "data-dismiss": "modal"}, "Close")
              )
            )
          )
        )
      );
    }
  });

  var IFrameModal = React.createClass({displayName: "IFrameModal",
    act: function() {
        var url = document.getElementById("insert-iframe-field").value,
            code = document.getElementById("insert-iframe-area").value,
            width = parseInt(document.getElementById("iframe-width-field").value) || 500,
            height = parseInt(document.getElementById("iframe-height-field").value) || 300,
            html;

        if (code.length > 0) {
          html = [
            "<br>",
            code,
            "<br>"
          ].join("\n");
        } else {
          html = [
            "<br>",
            "<iframe src=\"" + url + "\" width=\"" + width + "\" height=\"" + height + "\"></iframe>",
            "<br>"
          ].join("\n");
        }

        document.execCommand("insertHTML", false, html);
    },
    render: function() {
      return (
        React.createElement("div", {className: "modal fade", id: "insert-iframe-modal", tabIndex: "-1", role: "dialog", "aria-labelledby": "", "aria-hidden": "true"}, 
          React.createElement("div", {className: "modal-dialog"}, 
            React.createElement("div", {className: "modal-content"}, 
              React.createElement("div", {className: "modal-header"}, 
                React.createElement("button", {type: "button", className: "close", "data-dismiss": "modal"}, React.createElement("span", {"aria-hidden": "true"}, "×"), React.createElement("span", {className: "sr-only"}, "Close")), 
                React.createElement("h4", {className: "modal-title", id: "insert-iframe-modal-title"}, "Insert Iframe")
              ), 
              React.createElement("div", {className: "modal-body"}, 
                React.createElement("p", null, 
                  "An iframe will let you view and interact with another website inside of the current website." + ' ' +
                  "You can provide either a URL or, if provided, html embed code."
                ), 
                React.createElement("div", {className: "form-group"}, 
                  React.createElement("input", {id: "insert-iframe-field", type: "text", className: "form-control", placeholder: "Iframe URL"})
                ), 
                React.createElement("div", {className: "form-group"}, 
                  React.createElement("textarea", {id: "insert-iframe-area", className: "form-control", rows: "3", placeholder: "Iframe code"})
                ), 
                React.createElement("div", {className: "form-group"}, 
                  React.createElement("input", {id: "iframe-width-field", type: "text", className: "form-control", placeholder: "Width (Default 500 pixels)"})
                ), 
                React.createElement("div", {className: "form-group"}, 
                  React.createElement("input", {id: "iframe-height-field", type: "text", className: "form-control", placeholder: "Height (Default 300 pixels)"})
                ), 
                React.createElement("div", {className: "form-group"}, 
                  React.createElement("button", {id: "insert-iframe-btn", type: "button", className: "btn btn-primary", onClick: this.act}, 
                    React.createElement("span", {className: "glyphicon glyphicon-ok"}, " ", 
                      React.createElement("label", null, "Insert Iframe")
                    )
                  )
                )
              ), 
              React.createElement("div", {className: "modal-footer"}, 
                React.createElement("button", {type: "button", className: "btn btn-default", "data-dismiss": "modal"}, "Close")
              )
            )
          )
        )
      );
    }
  });

  var DataButton = React.createClass({displayName: "DataButton",
    render: function() {
      var id = this.props.name + "-btn",
          target = "#insert-" + this.props.name + "-modal",
          className = "glyphicon glyphicon-" + this.props.icon;
      return (
        React.createElement("button", {id: id, type: "button", className: "btn btn-primary", "data-toggle": "modal", "data-target": target}, 
          React.createElement("span", {className: className})
        )
      );
    }
  });

  var UndoButton = React.createClass({displayName: "UndoButton",
    act: function() {
      document.execCommand(this.props.action, false, null);
    },
    render: function() {
      var id = this.props.name + "-btn", inner;
      if (this.props.text) {
        inner = this.props.text
      } else {
        var className = "glyphicon glyphicon-" + this.props.icon;
        inner = React.createElement("span", {className: className});
      }

      return (
        React.createElement("button", {id: id, type: "button", className: "btn btn-primary", onClick: this.act}, 
          inner
        )
      );
    }
  });

  window.ARTERY = {Editor: Editor};
})(window);