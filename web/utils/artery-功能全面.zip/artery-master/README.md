# artery
Artery is a rich text editor built using [React](https://github.com/facebook/react) and [Bootstrap](https://github.com/twbs/bootstrap).
<p><img src="https://github.com/benglard/artery/blob/master/screenshot.png" /></p>

## Example Usage:
```html
<!DOCTYPE html>
<html>
  <head>
    <title>ARTERY</title>
    <link rel="stylesheet" href="http://netdna.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/js/bootstrap.min.js"></script>
    <link href="//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap-glyphicons.css" rel="stylesheet">
    <script src="http://fb.me/react-0.12.2.js"></script>
    <script src="http://fb.me/JSXTransformer-0.12.2.js"></script>
    <script type="text/jsx" src="index.jsx"></script>
  </head>
  <body>
    <div id="editor">
    </div>
    <script type="text/jsx">
      var onSave = function() {
        var content = $("#editor-content").html();
        $("#panel-content").html(content);
      }
      React.render(<ARTERY.Editor onSave={onSave} showHTMLButton={true} tooltips={true} />, document.getElementById("editor"));
    </script>
    <div id="panel-content">
    </div>
  </body>
</html>
```