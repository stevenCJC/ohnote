(function(window) {
  var Styles = {
    InLine: { display: "inline-block" },
    ButtonGroup: { marginRight: "5px" },
    Content: {
      height: "194px",
      border: "1px solid #ccc",
      overflow: "scroll"
    },
    HTMLButton: {
      display: "inline-block",
      float: "right"
    },
    HTML: {
      height: "194px",
      border: "1px solid #ccc",
      overflow: "scroll",
      display: "none"
    }
  }

  var TIPS = {
    "bold-btn": "Bold selection",
    "italic-btn": "Italicize selection",
    "underline-btn": "Underline selection",
    "strikeThrough-btn": "Strikethrough selection",
    "font-size-btn-group": "Selection fontsize",
    "font-color-btn-group": "Selection fontcolor",
    "superscript-btn": "Superscript selection",
    "subscript-btn": "Subscript selection",
    "H1-btn": "Heading type #1",
    "P-btn": "Paragraph text",
    "BLOCKQUOTE-btn": "Blockquote text",
    "bulleted-btn": "Make a bulleted list",
    "numbered-btn": "Make a numbered list",
    "horzline-btn": "Add a horizontal line",
    "justifyLeft-btn": "Left justify selection",
    "justifyCenter-btn": "Center justify selection",
    "justifyRight-btn": "Right justify selection",
    "indent-btn": "Indent select text selection",
    "outdent-btn": "Outdent select text selection",
    "link-btn": "Insert a link",
    "img-btn": "Insert an image",
    "vid-btn": "Insert a video",
    "iframe-btn": "Insert an iframe",
    "undo-btn": "Undo",
    "redo-btn": "Redo",
    "all-btn": "Select all",
    "remove-format-btn": "Remove selection formatting",
  }

  var Editor = React.createClass({
    getInitialState: function() {
      return {
        selection: window.getSelection() || document.getSelection() || document.selection,
        range: null,
        spanCounter: 0
      }
    },
    onContent: function() {
      this.setState({ range: this.state.selection.getRangeAt(0) })
    },
    changeSelectionCSS: function(property, details) {
      if (!this.state.range) return;

      var id = "text-" + this.state.spanCounter.toString(),
          newNode = document.createElement("span");
      newNode.id = id;
      this.state.range.surroundContents(newNode);
      this.state.spanCounter += 1;

      var elem = document.getElementById(id),
          prop = property === "font-size" ? "fontSize" : "color",
          det = property === "font-size" ? details + "px" : details;
      elem.style[prop] = det;

      this.state.range = null;
    },
    showHTML: function(html) {
      document.getElementById("editor-content").style.display = "none";
      var htmlElem = document.getElementById("html-content");
      htmlElem.innerText = html;
      htmlElem.style.display = "";
    },
    hideHTML: function() {
      document.getElementById("editor-content").style.display = "";
      document.getElementById("html-content").style.display = "none";
    },
    componentDidMount: function() {
      if (this.props.tooltips) {
        for (var btn in TIPS) {
          var tip = TIPS[btn];
          $("#" + btn).tooltip({
            trigger: "hover",
            title: tip,
            placement: "bottom"
          });
        }
      }
    },
    render: function() {
      var codeButton;
      if (this.props.showHTMLButton) {
        codeButton = <HTMLButton show={this.showHTML} hide={this.hideHTML} />
      }

      return (  
        <div id="ARTERY">  
          <div className="panel panel-info">
            <div className="panel-heading">
              <SaveButton on={this.props.onSave}/>
              <div id="edit-btns" style={Styles.InLine}>
                <div id="font-btns" className="btn-group" style={Styles.ButtonGroup}>
                  <FontButton action="bold" />
                  <FontButton action="italic" />
                  <UnderlineButton />
                  <StrikethroughButton />
                  <FontSizeButtonGroup 
                    sizes={[8, 10, 12, 14, 16, 18, 20, 22, 24, 26, 28, 30]}
                    act={this.changeSelectionCSS} />
                  <FontColorButtonGroup
                    colors={["black", "red", "green", "blue", "yellow", "purple", "grey"]}
                    act={this.changeSelectionCSS} />
                  <ScriptButton action="superscript" />
                  <ScriptButton action="subscript" />
                </div>
                <div id="heading-btns" className="btn-group" style={Styles.ButtonGroup}>
                  <HeadingButton heading="H1" icon="header" />
                  <HeadingButton heading="P" text="P" />
                  <HeadingButton heading="BLOCKQUOTE" icon="comment" />
                </div>
                <div id="organization-btns" className="btn-group" style={Styles.ButtonGroup}>
                  <ListButton name="bulleted" icon="list" action="insertUnorderedList" />
                  <ListButton name="numbered" icon="list-alt" action="insertOrderedList" />
                  <HorizontalLine />
                  <JustifyButton action="justifyLeft" icon="align-left" />
                  <JustifyButton action="justifyCenter" icon="align-center" />
                  <JustifyButton action="justifyRight" icon="align-right" />
                  <JustifyButton action="indent" icon="indent-left" />
                  <JustifyButton action="outdent" icon="indent-right" />
                </div>
                <div id="data-btns" className="btn-group" style={Styles.ButtonGroup}>
                  <DataButton name="link" icon="link" />
                  <DataButton name="img" icon="picture" />
                  <DataButton name="vid" icon="facetime-video" />
                  <DataButton name="iframe" icon="globe" />
                </div>
                <div id="undo-btns" className="btn-group" style={Styles.ButtonGroup}>
                  <UndoButton name="undo" icon="arrow-left" action="undo" />
                  <UndoButton name="redo" icon="arrow-right" action="redo" />
                  <UndoButton name="all" icon="font" action="selectAll" />
                  <UndoButton name="remove-format" icon="trash" action="removeFormat" />
                </div>
                {codeButton}
              </div>
            </div>
            <div 
              id="editor-content" 
              className="form-control" 
              contentEditable="true" 
              style={Styles.Content}
              onClick={this.onContent}>
            </div>
            <div
              id="html-content"
              type="text" 
              rows="9"
              className="form-control" 
              style={Styles.HTML}
              readOnly>
              </div>
          </div>
          <LinkModal />
          <ImageModal />
          <VideoModal />
          <IFrameModal />
        </div>
      );
    }
  });

  var SaveButton = React.createClass({
    render: function() {
      return (
        <button 
          id="save-btn"
          type="button"
          className="btn btn-default"
          style={Styles.ButtonGroup}
          onClick={this.props.on}>Save
        </button>
      ); 
    }
  });

  var HTMLButton = React.createClass({
    getInitialState: function() {
      return {on: false, text: 'HTML'};
    },
    act: function() {
      if (this.state.on) {
        this.setState({on: false, text: 'HTML'});
        this.props.hide();
      } else {
        this.setState({on: true, text: 'Text'});
        var html = document.getElementById("editor-content").innerHTML;
        this.props.show(html);
      }
    },
    render: function() {
      return (
          <button 
            id="code-btn" 
            type="button" 
            className="btn btn-default" 
            style={Styles.HTMLButton}
            onClick={this.act}>
            {this.state.text}
          </button>
      );
    }
  });

  var FontButton = React.createClass({
    act: function() {
      document.execCommand(this.props.action, false, null);
    },
    render: function() {
      var id = this.props.action + "-btn",
          spanClass = "glyphicon glyphicon-" + this.props.action;
      return (
        <button id={id} type="button" className="btn btn-primary" onClick={this.act}>
          <span className={spanClass}></span>
        </button>
      );
    }
  });

  var UnderlineButton = React.createClass({
    act: function() {
      document.execCommand("underline", false, null);
    },
    render: function() {
      return (
        <button id="underline-btn" type="button" className="btn btn-primary" onClick={this.act}>
          <u>U</u>
        </button>
      );
    }
  });

  var StrikethroughButton = React.createClass({
    act: function() {
      document.execCommand("strikeThrough", false, null);
    },
    render: function() {
      return (
        <button id="strikeThrough-btn" type="button" className="btn btn-primary" onClick={this.act}>
          <s>S</s>
        </button>
      );
    }
  });

  var HeadingButton = React.createClass({
    act: function() {
      document.execCommand("formatBlock", false, this.props.heading);
    },
    render: function() {
      var id = this.props.heading + "-btn", inner;
      if (this.props.text) {
        inner = <b>{this.props.text}</b>
      } else {
        var className = "glyphicon glyphicon-" + this.props.icon;
        inner = <span className={className}></span>;
      }
      return (
        <button id={id} type="button" className="btn btn-primary" onClick={this.act}>
          {inner}
        </button>
      );
    },
  });

  var FontSizeButton = React.createClass({
    act: function() {
      this.props.act("font-size", this.props.size);
    },
    render: function() {
      var sizeStr = this.props.size.toString();
      return (
        <li className="font-size-btn" onClick={this.act}>
          <a>{sizeStr}</a>
        </li>
      );
    }
  });

  var FontSizeButtonGroup = React.createClass({
    render: function() {
      var f = this.props.act;
      return (
        <div className="btn-group">
          <button id="font-size-btn-group" type="button" className="btn btn-primary dropdown-toggle" data-toggle="dropdown">
            <span className="glyphicon glyphicon-text-height"></span><span className="caret"></span>
          </button>
          <ul id="font-size-menu" className="dropdown-menu" role="menu">
            {this.props.sizes.map(function(size) {
              return <FontSizeButton key={size} size={size} act={f} />;
            })}
          </ul>
        </div>
      );
    }
  });

  var FontColorButton = React.createClass({
    act: function() {
      this.props.act("color", this.props.color);
    },
    render: function() {
      var color = this.props.color,
          title = color[0].toUpperCase() + color.substring(1);
      return (
        <li className="font-color-btn" onClick={this.act}>
          <a>{title}</a>
        </li>
      );
    }
  });

  var FontColorButtonGroup = React.createClass({
    render: function() {
      var f = this.props.act;
      return (
        <div className="btn-group">
          <button id="font-color-btn-group" type="button" className="btn btn-primary dropdown-toggle" data-toggle="dropdown">
            <span className="glyphicon glyphicon-tint"></span><span className="caret"></span>
          </button>
          <ul id="font-color-menu" className="dropdown-menu" role="menu">
            {this.props.colors.map(function(color) {
              return <FontColorButton key={color} color={color} act={f} />;
            })}
          </ul>
        </div>
      );
    }
  });

  var ScriptButton = React.createClass({
    act: function() {
      document.execCommand(this.props.action, false, null);
    },
    render: function() {
      var id = this.props.action + "-btn",
          sub = this.props.action.substring(2, 3) === "b",
          spanClass = "glyphicon glyphicon-chevron-" + (sub ? "down" : "up");
      return (
        <button id={id} type="button" className="btn btn-primary" onClick={this.act}>
          <span className={spanClass}></span>
        </button>
      );
    }
  });

  var ListButton = React.createClass({
    act: function() {
      document.execCommand(this.props.action, false, null);
    },
    render: function() {
      var id = this.props.name + "-btn",
          spanClass = "glyphicon glyphicon-" + this.props.icon;
      return (
        <button id={id} type="button" className="btn btn-primary" onClick={this.act}>
          <span className={spanClass}></span>
        </button>
      );
    }
  });

  var HorizontalLine = React.createClass({
    act: function() {
      document.execCommand("insertHorizontalRule", false, null);
    },
    render: function() {
      return (
        <button id="horzline-btn" type="button" className="btn btn-primary" onClick={this.act}>
          <span className="glyphicon glyphicon-minus"></span>
        </button>
      );
    }
  });

  var JustifyButton = React.createClass({
    act: function() {
      document.execCommand(this.props.action, false, null);
    },
    render: function() {
      var id = this.props.action + "-btn",
          spanClass = "glyphicon glyphicon-" + this.props.icon;
      return (
        <button id={id} type="button" className="btn btn-primary" onClick={this.act}>
          <span className={spanClass}></span>
        </button>
      );
    }
  });

  var LinkModal = React.createClass({
    insertLink: function() {
      var url = document.getElementById("insert-link-field").value;
      document.execCommand("createLink", false, url);
    },
    removeLink: function() {
      document.execCommand("unlink", false, null);
    },
    render: function() {
      return (
        <div className="modal fade" id="insert-link-modal" tabIndex="-1" role="dialog" aria-labelledby="" aria-hidden="true">
          <div className="modal-dialog">
            <div className="modal-content">
              <div className="modal-header">
                <button type="button" className="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span className="sr-only">Close</span></button>
                <h4 className="modal-title" id="insert-link-modal-title">Insert Link</h4>
              </div>
              <div className="modal-body">
                <div className="form-group">
                  <input id="insert-link-field" type="text" className="form-control" placeholder="Link" />
                </div>
                <div className="form-group">
                  <button id="insert-link-btn" type="button" className="btn btn-primary" onClick={this.insertLink}>
                    <span className="glyphicon glyphicon-ok">&nbsp;
                      <label>Insert Link</label>
                    </span>
                  </button>
                </div>
                <div className="form-group">
                  <button id="remove-link-btn" type="button" className="btn btn-primary" onClick={this.removeLink}>
                    <span className="glyphicon glyphicon-remove-circle">&nbsp;
                      <label>Remove Link</label>
                    </span>
                  </button>
                </div>
              </div>
              <div className="modal-footer">
                <button type="button" className="btn btn-default" data-dismiss="modal">Close</button>
              </div>
            </div>
          </div>
        </div>
      );
    }
  });

  var ImageModal = React.createClass({
    act: function() {
      var url = document.getElementById("insert-img-field").value;
      document.execCommand("insertImage", false, url);
    },
    render: function() {
      return (
        <div className="modal fade" id="insert-img-modal" tabIndex="-1" role="dialog" aria-labelledby="" aria-hidden="true">
          <div className="modal-dialog">
            <div className="modal-content">
              <div className="modal-header">
                <button type="button" className="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span className="sr-only">Close</span></button>
                <h4 className="modal-title" id="insert-img-modal-title">Insert Image</h4>
              </div>
              <div className="modal-body">
                <div className="form-group">
                  <input id="insert-img-field" type="text" className="form-control" placeholder="Image URL" />
                </div>
                <div className="form-group">
                  <button id="insert-img-btn" type="button" className="btn btn-primary" onClick={this.act}>
                    <span className="glyphicon glyphicon-ok">&nbsp;
                      <label>Insert Image</label>
                    </span>
                  </button>
                </div>
              </div>
              <div className="modal-footer">
                <button type="button" className="btn btn-default" data-dismiss="modal">Close</button>
              </div>
            </div>
          </div>
        </div>
      );
    }
  });

  var VideoModal = React.createClass({
    act: function() {
      var url = document.getElementById("insert-vid-field").value,
          width = parseInt(document.getElementById("vid-width-field").value) || 500,
          height = parseInt(document.getElementById("vid-height-field").value) || 300,
          html = ["<br>",
            "<video src=\"" + url + "\" width=\"" + width + "\" height=\"" + height + "\"" + " controls></video>",
            "<br>"
          ].join("\n");
      document.execCommand("insertHTML", false, html);
    },
    render: function() {
      return (
        <div className="modal fade" id="insert-vid-modal" tabIndex="-1" role="dialog" aria-labelledby="" aria-hidden="true">
          <div className="modal-dialog">
            <div className="modal-content">
              <div className="modal-header">
                <button type="button" className="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span className="sr-only">Close</span></button>
                <h4 className="modal-title" id="insert-vid-modal-title">Insert Video</h4>
              </div>
              <div className="modal-body">
                <p>
                  Note: YouTube and Vimeo (and possibly others) tend to provide iframe embed code. If
                  you have that, click the globe button next to the video button and paste it in. Thanks!
                </p>
                <div className="form-group">
                  <input id="insert-vid-field" type="text" className="form-control" placeholder="Video URL" />
                </div>
                <div className="form-group">
                  <input id="vid-width-field" type="text" className="form-control" placeholder="Width (Default 500 pixels)" />
                </div>
                <div className="form-group">
                  <input id="vid-height-field" type="text" className="form-control" placeholder="Height (Default 300 pixels)" />
                </div>
                <div className="form-group">
                  <button id="insert-vid-btn" type="button" className="btn btn-primary" onClick={this.act}>
                    <span className="glyphicon glyphicon-ok">&nbsp;
                      <label>Insert Video</label>
                    </span>
                  </button>
                </div>
              </div>
              <div className="modal-footer">
                <button type="button" className="btn btn-default" data-dismiss="modal">Close</button>
              </div>
            </div>
          </div>
        </div>
      );
    }
  });

  var IFrameModal = React.createClass({
    act: function() {
        var url = document.getElementById("insert-iframe-field").value,
            code = document.getElementById("insert-iframe-area").value,
            width = parseInt(document.getElementById("iframe-width-field").value) || 500,
            height = parseInt(document.getElementById("iframe-height-field").value) || 300,
            html;

        if (code.length > 0) {
          html = [
            "<br>",
            code,
            "<br>"
          ].join("\n");
        } else {
          html = [
            "<br>",
            "<iframe src=\"" + url + "\" width=\"" + width + "\" height=\"" + height + "\"></iframe>",
            "<br>"
          ].join("\n");
        }

        document.execCommand("insertHTML", false, html);
    },
    render: function() {
      return (
        <div className="modal fade" id="insert-iframe-modal" tabIndex="-1" role="dialog" aria-labelledby="" aria-hidden="true">
          <div className="modal-dialog">
            <div className="modal-content">
              <div className="modal-header">
                <button type="button" className="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span className="sr-only">Close</span></button>
                <h4 className="modal-title" id="insert-iframe-modal-title">Insert Iframe</h4>
              </div>
              <div className="modal-body">
                <p>
                  An iframe will let you view and interact with another website inside of the current website.
                  You can provide either a URL or, if provided, html embed code.
                </p>
                <div className="form-group">
                  <input id="insert-iframe-field" type="text" className="form-control" placeholder="Iframe URL" />
                </div>
                <div className="form-group">
                  <textarea id="insert-iframe-area" className="form-control" rows="3" placeholder="Iframe code"></textarea> 
                </div>
                <div className="form-group">
                  <input id="iframe-width-field" type="text" className="form-control" placeholder="Width (Default 500 pixels)" />
                </div>
                <div className="form-group">
                  <input id="iframe-height-field" type="text" className="form-control" placeholder="Height (Default 300 pixels)" />
                </div>
                <div className="form-group">
                  <button id="insert-iframe-btn" type="button" className="btn btn-primary" onClick={this.act}>
                    <span className="glyphicon glyphicon-ok">&nbsp;
                      <label>Insert Iframe</label>
                    </span>
                  </button>
                </div>
              </div>
              <div className="modal-footer">
                <button type="button" className="btn btn-default" data-dismiss="modal">Close</button>
              </div>
            </div>
          </div>
        </div>
      );
    }
  });

  var DataButton = React.createClass({
    render: function() {
      var id = this.props.name + "-btn",
          target = "#insert-" + this.props.name + "-modal",
          className = "glyphicon glyphicon-" + this.props.icon;
      return (
        <button id={id} type="button" className="btn btn-primary" data-toggle="modal" data-target={target}>
          <span className={className}></span>
        </button>
      );
    }
  });

  var UndoButton = React.createClass({
    act: function() {
      document.execCommand(this.props.action, false, null);
    },
    render: function() {
      var id = this.props.name + "-btn", inner;
      if (this.props.text) {
        inner = this.props.text
      } else {
        var className = "glyphicon glyphicon-" + this.props.icon;
        inner = <span className={className}></span>;
      }

      return (
        <button id={id} type="button" className="btn btn-primary" onClick={this.act}>
          {inner}
        </button>
      );
    }
  });

  window.ARTERY = {Editor: Editor};
})(window);