import TextEditor from './TextEditor';

export default TextEditor;
