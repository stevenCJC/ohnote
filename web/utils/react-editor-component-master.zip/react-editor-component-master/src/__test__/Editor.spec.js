
import Editor from 'Editor';

describe('dummy spec', ()=> {

	it('should show karma is running', ()=> {
		expect(Editor).toBeTruthy();
	});
});
