export const SAVED_SELECTION = Symbol('savedSelection');
export const PLACEHOLDER = '\u200B';
