import React, { PropTypes, Component } from 'react';

export default class RerteMain extends Component {
	constructor (props) {
		super(props);
	}
	render () {
		return (
			<div contentEditable="true" className="RerteMain">
			</div>
		);
	}
}
