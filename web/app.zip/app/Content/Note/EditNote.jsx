import React, { Component, PropTypes } from 'react'
import { connect } from 'react-redux'
import ReactDOM from 'react-dom';
import {Link} from 'react-router';

import 'utils/ueditor/ueditor.config';
import 'utils/ueditor/ueditor.all';
import 'utils/ueditor/lang/zh-cn/zh-cn';

require('./editNote.less');
import 'utils/ueditor/themes/default/css/ueditor.css';


@connect((state)=>{
	let {meta={},activeNote={}}=state.notes;
	return {meta,activeNote};
})
export default class EditNote extends Component {
	constructor(props) {
		super(props);
		this.state={};
	}

	handleTitleChange(e){
		this.setState({
			title:e.target.value
		});
		this.note.title=e.target.value;
		this.props.dispatch('updateNote',{...this.note});
	}
	handleContentChange(e){
		var target=e.target;
		setTimeout(()=>{
			this.setState({
				content:target.innerHTML
			});
			this.note.content=target.innerHTML;

			var text=(target.innerText||'').trim();
			text=/[^\n\r]*/.exec(text)[0];
			text=text.trim().substr(0,100).trim();
			console.log('innerText',text);
			this.note.tips=text;
			this.props.dispatch('updateNote',{...this.note});
			console.log({...this.note});
		},0);

	}



	componentDidMount(){
		///this.editor=ReactDOM.findDOMNode(this.refs.editor);
		///this.editor.contentEditable=true;
		var ue = UE.getEditor('richEditor',{
			autoFloatEnabled : true,
			wordCount:false, //关闭字数统计
			elementPathEnabled:false,//关闭elementPath
			minFrameHeight:800,
			topOffset:50,
		});
		/*var ue = new UE.Editor();
		 ue.render('richEditor',{
			autoFloatEnabled : false,
			wordCount:false, //关闭字数统计
			elementPathEnabled:false//关闭elementPath
		})*/

		ue.ready(function(){

			ue.setContent('', true);

		});
	}

	componentWillReceiveProps(props){
		if(props.meta.action==='getNoteDetails') {
			this.note = props.activeNote;
			this.setState({
				title: this.note.title,
				content: this.note.content
			});
			this.editor.innerHTML=this.note.content;
		}
	}

	render() {
		return (
			<section className="edit-note">
				<header>
					<input ref="title" type="text" value={this.state.title} onChange={this.handleTitleChange.bind(this)} />
				</header>
				<section>

					<div ref="editor" id="richEditor"
						 className="rich-editor"></div>

				</section>
			</section>

		)
	}
}


